create view DLUGIE_MYSZY as
  select NUMER_MYSZY
from MYSZY
where DLUGOSC > 10
/

